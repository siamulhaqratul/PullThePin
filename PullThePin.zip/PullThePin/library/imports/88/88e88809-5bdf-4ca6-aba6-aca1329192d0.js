"use strict";
cc._RF.push(module, '88e88gJW99MpqumrKEykZLQ', 'game');
// Scripts/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player: cc.Node,
    hand: cc.Node,
    pinTop: cc.Node,
    pinTop2: cc.Node,
    pinLeft: cc.Node,
    pinRight: cc.Node,
    stone: cc.Node,
    gold: cc.Node,
    blast: cc.Node,
    blast2: cc.Node,
    soul: cc.Node,
    victory: cc.Node,
    defeat: cc.Node,
    download: cc.Node,
    box: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true;
    this.blast.active = false;
    this.blast2.active = false;
    this.soul.active = false;
    this.pinTop2.active = false;
    this.victory.active = false;
    this.defeat.active = false;
    this.scheduleOnce(function () {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
    }, 5);
    this.pinTop.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
      this.pinTop2.runAction(cc.moveTo(0.5, 0, 355));
      this.pinMove();
      return false;
    }, this);
    this.pinTop2.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
      this.pinTop2.runAction(cc.moveTo(0.5, 0, 355));
      this.pinMove();
      return false;
    }, this);
    this.download.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
    this.victory.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
    this.defeat.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
  },
  pinMove: function pinMove() {
    this.pinRight.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinRight.runAction(cc.moveBy(0.5, 185, 0)); // this.scheduleOnce(function () {
      //     this.stone.runAction(cc.moveTo(1, 102.427, -327));
      // }, 1);

      this.scheduleOnce(function () {
        this.blast.active = true;
      }, 2);
      this.scheduleOnce(function () {
        this.player.destroy();
        this.soul.active = true;
      }, 2.2);
      this.scheduleOnce(function () {
        this.blast.destroy();
      }, 3);
      this.scheduleOnce(function () {
        this.box.destroy();
        this.download.destroy();
        this.pinRight.destroy();
        this.pinLeft.destroy();
        this.gold.destroy();
        this.defeat.active = true;
      }, 3.7);
      return false;
    }, this);
    this.pinLeft.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinLeft.runAction(cc.moveBy(0.5, -185, 0)); // this.scheduleOnce(function () {
      //     this.gold.runAction(cc.moveTo(1, -162.652, -373.194));
      // }, 1);

      this.scheduleOnce(function () {
        this.player.runAction(cc.moveBy(1, -185, 0));
      }, 2);
      this.scheduleOnce(function () {
        this.blast2.active = true;
        this.gold.destroy();
      }, 2.8);
      this.scheduleOnce(function () {
        this.blast2.destroy();
        this.box.destroy();
        this.download.destroy();
        this.stone.destroy();
        this.pinRight.destroy();
        this.pinLeft.destroy();
        this.victory.active = true;
      }, 4.5);
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();