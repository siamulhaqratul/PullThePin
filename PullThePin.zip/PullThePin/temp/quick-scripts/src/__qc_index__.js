
require('./assets/Scripts/game');
