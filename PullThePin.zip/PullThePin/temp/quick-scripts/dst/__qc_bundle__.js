
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Scripts/game');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '88e88gJW99MpqumrKEykZLQ', 'game');
// Scripts/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player: cc.Node,
    hand: cc.Node,
    pinTop: cc.Node,
    pinTop2: cc.Node,
    pinLeft: cc.Node,
    pinRight: cc.Node,
    stone: cc.Node,
    gold: cc.Node,
    blast: cc.Node,
    blast2: cc.Node,
    soul: cc.Node,
    victory: cc.Node,
    defeat: cc.Node,
    download: cc.Node,
    box: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true;
    this.blast.active = false;
    this.blast2.active = false;
    this.soul.active = false;
    this.pinTop2.active = false;
    this.victory.active = false;
    this.defeat.active = false;
    this.scheduleOnce(function () {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
    }, 5);
    this.pinTop.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
      this.pinTop2.runAction(cc.moveTo(0.5, 0, 355));
      this.pinMove();
      return false;
    }, this);
    this.pinTop2.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinTop.destroy();
      this.hand.destroy();
      this.pinTop2.active = true;
      this.pinTop2.runAction(cc.moveTo(0.5, 0, 355));
      this.pinMove();
      return false;
    }, this);
    this.download.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
    this.victory.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
    this.defeat.on(cc.Node.EventType.TOUCH_START, function (event) {
      window.smartad_sdk();
    });
  },
  pinMove: function pinMove() {
    this.pinRight.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinRight.runAction(cc.moveBy(0.5, 185, 0)); // this.scheduleOnce(function () {
      //     this.stone.runAction(cc.moveTo(1, 102.427, -327));
      // }, 1);

      this.scheduleOnce(function () {
        this.blast.active = true;
      }, 2);
      this.scheduleOnce(function () {
        this.player.destroy();
        this.soul.active = true;
      }, 2.2);
      this.scheduleOnce(function () {
        this.blast.destroy();
      }, 3);
      this.scheduleOnce(function () {
        this.box.destroy();
        this.download.destroy();
        this.pinRight.destroy();
        this.pinLeft.destroy();
        this.gold.destroy();
        this.defeat.active = true;
      }, 3.7);
      return false;
    }, this);
    this.pinLeft.on(cc.Node.EventType.TOUCH_START, function (event) {
      this.pinLeft.runAction(cc.moveBy(0.5, -185, 0)); // this.scheduleOnce(function () {
      //     this.gold.runAction(cc.moveTo(1, -162.652, -373.194));
      // }, 1);

      this.scheduleOnce(function () {
        this.player.runAction(cc.moveBy(1, -185, 0));
      }, 2);
      this.scheduleOnce(function () {
        this.blast2.active = true;
        this.gold.destroy();
      }, 2.8);
      this.scheduleOnce(function () {
        this.blast2.destroy();
        this.box.destroy();
        this.download.destroy();
        this.stone.destroy();
        this.pinRight.destroy();
        this.pinLeft.destroy();
        this.victory.active = true;
      }, 4.5);
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL2dhbWUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJOb2RlIiwiaGFuZCIsInBpblRvcCIsInBpblRvcDIiLCJwaW5MZWZ0IiwicGluUmlnaHQiLCJzdG9uZSIsImdvbGQiLCJibGFzdCIsImJsYXN0MiIsInNvdWwiLCJ2aWN0b3J5IiwiZGVmZWF0IiwiZG93bmxvYWQiLCJib3giLCJvbkxvYWQiLCJkaXJlY3RvciIsImdldFBoeXNpY3NNYW5hZ2VyIiwiZW5hYmxlZCIsImFjdGl2ZSIsInNjaGVkdWxlT25jZSIsImRlc3Ryb3kiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiZXZlbnQiLCJydW5BY3Rpb24iLCJtb3ZlVG8iLCJwaW5Nb3ZlIiwid2luZG93Iiwic21hcnRhZF9zZGsiLCJtb3ZlQnkiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFFTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLE1BQU0sRUFBRUosRUFBRSxDQUFDSyxJQURIO0FBRVJDLElBQUFBLElBQUksRUFBRU4sRUFBRSxDQUFDSyxJQUZEO0FBR1JFLElBQUFBLE1BQU0sRUFBRVAsRUFBRSxDQUFDSyxJQUhIO0FBSVJHLElBQUFBLE9BQU8sRUFBRVIsRUFBRSxDQUFDSyxJQUpKO0FBS1JJLElBQUFBLE9BQU8sRUFBRVQsRUFBRSxDQUFDSyxJQUxKO0FBTVJLLElBQUFBLFFBQVEsRUFBRVYsRUFBRSxDQUFDSyxJQU5MO0FBT1JNLElBQUFBLEtBQUssRUFBRVgsRUFBRSxDQUFDSyxJQVBGO0FBUVJPLElBQUFBLElBQUksRUFBRVosRUFBRSxDQUFDSyxJQVJEO0FBU1JRLElBQUFBLEtBQUssRUFBRWIsRUFBRSxDQUFDSyxJQVRGO0FBVVJTLElBQUFBLE1BQU0sRUFBRWQsRUFBRSxDQUFDSyxJQVZIO0FBV1JVLElBQUFBLElBQUksRUFBRWYsRUFBRSxDQUFDSyxJQVhEO0FBWVJXLElBQUFBLE9BQU8sRUFBRWhCLEVBQUUsQ0FBQ0ssSUFaSjtBQWFSWSxJQUFBQSxNQUFNLEVBQUVqQixFQUFFLENBQUNLLElBYkg7QUFjUmEsSUFBQUEsUUFBUSxFQUFFbEIsRUFBRSxDQUFDSyxJQWRMO0FBZVJjLElBQUFBLEdBQUcsRUFBRW5CLEVBQUUsQ0FBQ0s7QUFmQSxHQUZQO0FBb0JMO0FBRUFlLEVBQUFBLE1BdEJLLG9CQXNCSTtBQUNMcEIsSUFBQUEsRUFBRSxDQUFDcUIsUUFBSCxDQUFZQyxpQkFBWixHQUFnQ0MsT0FBaEMsR0FBMEMsSUFBMUM7QUFDQSxTQUFLVixLQUFMLENBQVdXLE1BQVgsR0FBb0IsS0FBcEI7QUFDQSxTQUFLVixNQUFMLENBQVlVLE1BQVosR0FBcUIsS0FBckI7QUFDQSxTQUFLVCxJQUFMLENBQVVTLE1BQVYsR0FBbUIsS0FBbkI7QUFDQSxTQUFLaEIsT0FBTCxDQUFhZ0IsTUFBYixHQUFzQixLQUF0QjtBQUNBLFNBQUtSLE9BQUwsQ0FBYVEsTUFBYixHQUFzQixLQUF0QjtBQUNBLFNBQUtQLE1BQUwsQ0FBWU8sTUFBWixHQUFxQixLQUFyQjtBQUNBLFNBQUtDLFlBQUwsQ0FDSSxZQUFVO0FBQ04sV0FBS2xCLE1BQUwsQ0FBWW1CLE9BQVo7QUFDQSxXQUFLcEIsSUFBTCxDQUFVb0IsT0FBVjtBQUNBLFdBQUtsQixPQUFMLENBQWFnQixNQUFiLEdBQXNCLElBQXRCO0FBQ0gsS0FMTCxFQUtNLENBTE47QUFPQSxTQUFLakIsTUFBTCxDQUFZb0IsRUFBWixDQUNJM0IsRUFBRSxDQUFDSyxJQUFILENBQVF1QixTQUFSLENBQWtCQyxXQUR0QixFQUVJLFVBQVVDLEtBQVYsRUFBaUI7QUFDYixXQUFLdkIsTUFBTCxDQUFZbUIsT0FBWjtBQUNBLFdBQUtwQixJQUFMLENBQVVvQixPQUFWO0FBQ0EsV0FBS2xCLE9BQUwsQ0FBYWdCLE1BQWIsR0FBc0IsSUFBdEI7QUFDQSxXQUFLaEIsT0FBTCxDQUFhdUIsU0FBYixDQUF1Qi9CLEVBQUUsQ0FBQ2dDLE1BQUgsQ0FBVSxHQUFWLEVBQWUsQ0FBZixFQUFrQixHQUFsQixDQUF2QjtBQUNBLFdBQUtDLE9BQUw7QUFDQSxhQUFPLEtBQVA7QUFDSCxLQVRMLEVBVUksSUFWSjtBQVlBLFNBQUt6QixPQUFMLENBQWFtQixFQUFiLENBQ0kzQixFQUFFLENBQUNLLElBQUgsQ0FBUXVCLFNBQVIsQ0FBa0JDLFdBRHRCLEVBRUksVUFBVUMsS0FBVixFQUFpQjtBQUNiLFdBQUt2QixNQUFMLENBQVltQixPQUFaO0FBQ0EsV0FBS3BCLElBQUwsQ0FBVW9CLE9BQVY7QUFDQSxXQUFLbEIsT0FBTCxDQUFhZ0IsTUFBYixHQUFzQixJQUF0QjtBQUNBLFdBQUtoQixPQUFMLENBQWF1QixTQUFiLENBQXVCL0IsRUFBRSxDQUFDZ0MsTUFBSCxDQUFVLEdBQVYsRUFBZSxDQUFmLEVBQWtCLEdBQWxCLENBQXZCO0FBQ0EsV0FBS0MsT0FBTDtBQUNBLGFBQU8sS0FBUDtBQUNILEtBVEwsRUFVSSxJQVZKO0FBWUEsU0FBS2YsUUFBTCxDQUFjUyxFQUFkLENBQ0kzQixFQUFFLENBQUNLLElBQUgsQ0FBUXVCLFNBQVIsQ0FBa0JDLFdBRHRCLEVBRUksVUFBU0MsS0FBVCxFQUFnQjtBQUNaSSxNQUFBQSxNQUFNLENBQUNDLFdBQVA7QUFDSCxLQUpMO0FBTUEsU0FBS25CLE9BQUwsQ0FBYVcsRUFBYixDQUNJM0IsRUFBRSxDQUFDSyxJQUFILENBQVF1QixTQUFSLENBQWtCQyxXQUR0QixFQUVJLFVBQVNDLEtBQVQsRUFBZ0I7QUFDWkksTUFBQUEsTUFBTSxDQUFDQyxXQUFQO0FBQ0gsS0FKTDtBQU1BLFNBQUtsQixNQUFMLENBQVlVLEVBQVosQ0FDSTNCLEVBQUUsQ0FBQ0ssSUFBSCxDQUFRdUIsU0FBUixDQUFrQkMsV0FEdEIsRUFFSSxVQUFTQyxLQUFULEVBQWdCO0FBQ1pJLE1BQUFBLE1BQU0sQ0FBQ0MsV0FBUDtBQUNILEtBSkw7QUFNSCxHQS9FSTtBQWdGTEYsRUFBQUEsT0FoRksscUJBZ0ZLO0FBQ04sU0FBS3ZCLFFBQUwsQ0FBY2lCLEVBQWQsQ0FDSTNCLEVBQUUsQ0FBQ0ssSUFBSCxDQUFRdUIsU0FBUixDQUFrQkMsV0FEdEIsRUFFSSxVQUFVQyxLQUFWLEVBQWlCO0FBQ2IsV0FBS3BCLFFBQUwsQ0FBY3FCLFNBQWQsQ0FBd0IvQixFQUFFLENBQUNvQyxNQUFILENBQVUsR0FBVixFQUFlLEdBQWYsRUFBb0IsQ0FBcEIsQ0FBeEIsRUFEYSxDQUViO0FBQ0E7QUFDQTs7QUFDQSxXQUFLWCxZQUFMLENBQWtCLFlBQVk7QUFDMUIsYUFBS1osS0FBTCxDQUFXVyxNQUFYLEdBQW9CLElBQXBCO0FBQ0gsT0FGRCxFQUVHLENBRkg7QUFHQSxXQUFLQyxZQUFMLENBQWtCLFlBQVk7QUFDMUIsYUFBS3JCLE1BQUwsQ0FBWXNCLE9BQVo7QUFDQSxhQUFLWCxJQUFMLENBQVVTLE1BQVYsR0FBbUIsSUFBbkI7QUFDSCxPQUhELEVBR0csR0FISDtBQUlBLFdBQUtDLFlBQUwsQ0FBa0IsWUFBWTtBQUMxQixhQUFLWixLQUFMLENBQVdhLE9BQVg7QUFDSCxPQUZELEVBRUcsQ0FGSDtBQUdBLFdBQUtELFlBQUwsQ0FBa0IsWUFBWTtBQUMxQixhQUFLTixHQUFMLENBQVNPLE9BQVQ7QUFDQSxhQUFLUixRQUFMLENBQWNRLE9BQWQ7QUFDQSxhQUFLaEIsUUFBTCxDQUFjZ0IsT0FBZDtBQUNBLGFBQUtqQixPQUFMLENBQWFpQixPQUFiO0FBQ0EsYUFBS2QsSUFBTCxDQUFVYyxPQUFWO0FBQ0EsYUFBS1QsTUFBTCxDQUFZTyxNQUFaLEdBQXFCLElBQXJCO0FBQ0gsT0FQRCxFQU9HLEdBUEg7QUFRQSxhQUFPLEtBQVA7QUFDSCxLQTFCTCxFQTJCSSxJQTNCSjtBQTZCQSxTQUFLZixPQUFMLENBQWFrQixFQUFiLENBQ0kzQixFQUFFLENBQUNLLElBQUgsQ0FBUXVCLFNBQVIsQ0FBa0JDLFdBRHRCLEVBRUksVUFBVUMsS0FBVixFQUFpQjtBQUNiLFdBQUtyQixPQUFMLENBQWFzQixTQUFiLENBQXVCL0IsRUFBRSxDQUFDb0MsTUFBSCxDQUFVLEdBQVYsRUFBZSxDQUFDLEdBQWhCLEVBQXFCLENBQXJCLENBQXZCLEVBRGEsQ0FFYjtBQUNBO0FBQ0E7O0FBQ0EsV0FBS1gsWUFBTCxDQUFrQixZQUFZO0FBQzFCLGFBQUtyQixNQUFMLENBQVkyQixTQUFaLENBQXNCL0IsRUFBRSxDQUFDb0MsTUFBSCxDQUFVLENBQVYsRUFBYSxDQUFDLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBdEI7QUFDSCxPQUZELEVBRUcsQ0FGSDtBQUdBLFdBQUtYLFlBQUwsQ0FBa0IsWUFBWTtBQUMxQixhQUFLWCxNQUFMLENBQVlVLE1BQVosR0FBcUIsSUFBckI7QUFDQSxhQUFLWixJQUFMLENBQVVjLE9BQVY7QUFDSCxPQUhELEVBR0csR0FISDtBQUlBLFdBQUtELFlBQUwsQ0FBa0IsWUFBWTtBQUMxQixhQUFLWCxNQUFMLENBQVlZLE9BQVo7QUFDQSxhQUFLUCxHQUFMLENBQVNPLE9BQVQ7QUFDQSxhQUFLUixRQUFMLENBQWNRLE9BQWQ7QUFDQSxhQUFLZixLQUFMLENBQVdlLE9BQVg7QUFDQSxhQUFLaEIsUUFBTCxDQUFjZ0IsT0FBZDtBQUNBLGFBQUtqQixPQUFMLENBQWFpQixPQUFiO0FBQ0EsYUFBS1YsT0FBTCxDQUFhUSxNQUFiLEdBQXNCLElBQXRCO0FBQ0gsT0FSRCxFQVFHLEdBUkg7QUFTSCxLQXZCTCxFQXdCSSxJQXhCSjtBQTBCSCxHQXhJSTtBQXlJTGEsRUFBQUEsS0F6SUssbUJBeUlHLENBQUcsQ0F6SU4sQ0EySUw7O0FBM0lLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBwbGF5ZXI6IGNjLk5vZGUsXG4gICAgICAgIGhhbmQ6IGNjLk5vZGUsXG4gICAgICAgIHBpblRvcDogY2MuTm9kZSxcbiAgICAgICAgcGluVG9wMjogY2MuTm9kZSxcbiAgICAgICAgcGluTGVmdDogY2MuTm9kZSxcbiAgICAgICAgcGluUmlnaHQ6IGNjLk5vZGUsXG4gICAgICAgIHN0b25lOiBjYy5Ob2RlLFxuICAgICAgICBnb2xkOiBjYy5Ob2RlLFxuICAgICAgICBibGFzdDogY2MuTm9kZSxcbiAgICAgICAgYmxhc3QyOiBjYy5Ob2RlLFxuICAgICAgICBzb3VsOiBjYy5Ob2RlLFxuICAgICAgICB2aWN0b3J5OiBjYy5Ob2RlLFxuICAgICAgICBkZWZlYXQ6IGNjLk5vZGUsXG4gICAgICAgIGRvd25sb2FkOiBjYy5Ob2RlLFxuICAgICAgICBib3g6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFBoeXNpY3NNYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XG4gICAgICAgIHRoaXMuYmxhc3QuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuYmxhc3QyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNvdWwuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMucGluVG9wMi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy52aWN0b3J5LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmRlZmVhdC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoXG4gICAgICAgICAgICBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgIHRoaXMucGluVG9wLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIHRoaXMucGluVG9wMi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgfSw1XG4gICAgICAgICk7XG4gICAgICAgIHRoaXMucGluVG9wLm9uKFxuICAgICAgICAgICAgY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsXG4gICAgICAgICAgICBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBpblRvcC5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5oYW5kLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICB0aGlzLnBpblRvcDIuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLnBpblRvcDIucnVuQWN0aW9uKGNjLm1vdmVUbygwLjUsIDAsIDM1NSkpO1xuICAgICAgICAgICAgICAgIHRoaXMucGluTW92ZSgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0aGlzXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMucGluVG9wMi5vbihcbiAgICAgICAgICAgIGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULFxuICAgICAgICAgICAgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5waW5Ub3AuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIHRoaXMuaGFuZC5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5waW5Ub3AyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5waW5Ub3AyLnJ1bkFjdGlvbihjYy5tb3ZlVG8oMC41LCAwLCAzNTUpKTtcbiAgICAgICAgICAgICAgICB0aGlzLnBpbk1vdmUoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGhpc1xuICAgICAgICApO1xuICAgICAgICB0aGlzLmRvd25sb2FkLm9uKFxuICAgICAgICAgICAgY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsXG4gICAgICAgICAgICBmdW5jdGlvbihldmVudCkge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5zbWFydGFkX3NkaygpXG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIHRoaXMudmljdG9yeS5vbihcbiAgICAgICAgICAgIGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULFxuICAgICAgICAgICAgZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuc21hcnRhZF9zZGsoKVxuICAgICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICB0aGlzLmRlZmVhdC5vbihcbiAgICAgICAgICAgIGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULFxuICAgICAgICAgICAgZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuc21hcnRhZF9zZGsoKVxuICAgICAgICAgICAgfVxuICAgICAgICApXG4gICAgfSxcbiAgICBwaW5Nb3ZlKCkge1xuICAgICAgICB0aGlzLnBpblJpZ2h0Lm9uKFxuICAgICAgICAgICAgY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsXG4gICAgICAgICAgICBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBpblJpZ2h0LnJ1bkFjdGlvbihjYy5tb3ZlQnkoMC41LCAxODUsIDApKTtcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgIHRoaXMuc3RvbmUucnVuQWN0aW9uKGNjLm1vdmVUbygxLCAxMDIuNDI3LCAtMzI3KSk7XG4gICAgICAgICAgICAgICAgLy8gfSwgMSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJsYXN0LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSwgMik7XG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsYXllci5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc291bC5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH0sIDIuMik7XG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJsYXN0LmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICB9LCAzKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYm94LmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kb3dubG9hZC5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGluUmlnaHQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBpbkxlZnQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdvbGQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRlZmVhdC5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH0sIDMuNyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRoaXNcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5waW5MZWZ0Lm9uKFxuICAgICAgICAgICAgY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsXG4gICAgICAgICAgICBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBpbkxlZnQucnVuQWN0aW9uKGNjLm1vdmVCeSgwLjUsIC0xODUsIDApKTtcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgIHRoaXMuZ29sZC5ydW5BY3Rpb24oY2MubW92ZVRvKDEsIC0xNjIuNjUyLCAtMzczLjE5NCkpO1xuICAgICAgICAgICAgICAgIC8vIH0sIDEpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbGF5ZXIucnVuQWN0aW9uKGNjLm1vdmVCeSgxLCAtMTg1LCAwKSk7XG4gICAgICAgICAgICAgICAgfSwgMik7XG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJsYXN0Mi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdvbGQuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIH0sIDIuOCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJsYXN0Mi5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYm94LmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kb3dubG9hZC5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RvbmUuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBpblJpZ2h0LmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5waW5MZWZ0LmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52aWN0b3J5LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSwgNC41KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0aGlzXG4gICAgICAgICk7XG4gICAgfSxcbiAgICBzdGFydCgpIHsgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------
